package me.hwang.demo;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import android.widget.SearchView;

import android.support.v7.app.AppCompatActivity;




public class SearchDemo extends AppCompatActivity {
    private me.hwang.demo.SearchView searchView;

    private static void setAndroidNativeLightStatusBar(Activity paramActivity, boolean paramBoolean) {
        View view = paramActivity.getWindow().getDecorView();
        if (paramBoolean) {
            view.setSystemUiVisibility(9216);
            return;
        }
        view.setSystemUiVisibility(1280);
    }

    protected void onCreate(Bundle paramBundle) {
        super.onCreate(paramBundle);
        setAndroidNativeLightStatusBar((Activity)this, true);
        setContentView(R.layout.activity_search);
        this.searchView = (me.hwang.demo.SearchView)findViewById(R.id.search_view);
        final String str[] = new String [2];
        str[0] = getIntent().getStringExtra("souta");
        if (str != null && str[0].compareTo("") != 0) {
            this.searchView.setText(str[0]);
            this.searchView.setSelection(str[0].length());
        }
        this.searchView.setOnClickSearch(new bCallBack() {
            public void BackAciton() {
                Intent intent = new Intent((Context)SearchDemo.this, Demo6Activity.class);
                intent.putExtra("name", str[0]);
                SearchDemo.this.startActivity(intent);
                SearchDemo.this.finish();
            }
        });
        searchView.setOnClickBack(new bCallBack() {
            @Override
            public void BackAciton() {
                finish();
            }
        });
        this.searchView.setOnClickBack(new bCallBack() {
            public void BackAciton() {
                Intent intent = new Intent((Context)SearchDemo.this, Demo6Activity.class);
                intent.putExtra("name", str[0]);
                SearchDemo.this.startActivity(intent);
                SearchDemo.this.finish();
            }
        });
    }
}
