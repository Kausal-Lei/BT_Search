package me.hwang.demo;

/**
 * Created by Carson_Ho on 17/8/10.
 */

public interface ICallBack {
    void SearchAciton(String string);

}
