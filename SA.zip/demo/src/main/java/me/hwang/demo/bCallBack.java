package me.hwang.demo;

/**
 * Created by Carson_Ho on 17/8/11.
 */

public interface bCallBack {
    void BackAciton();
}
